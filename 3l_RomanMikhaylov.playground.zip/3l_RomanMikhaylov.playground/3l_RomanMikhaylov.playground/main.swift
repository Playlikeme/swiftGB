//
//  main.swift
//  3l_RomanMikhaylov.playground
//
//  Created by Роман Михайлов on 25.02.2021.
//

import Foundation

enum engineState {
case включено, выключено
}

enum windowState {
case открыты, закрыты
}

enum trunkState {
case полный, пустой
}

struct someCar {
let brand : String
let model : String
var color : String
mutating func changeColor(c:String) {
switch c {
case "белый":
self.color = "белый"
case "черный":
self.color = "черный"
case "красный":
self.color = "красный"
case "голубой":
self.color = "голубой"
default:
print("Неверный ввод данных.")
}
}
let release : Int
var trunkVolume : Double {
willSet {
if (trunkState == .пустой) && (trunkVolume > 0) && (trunkVolume != 0) && (newValue < trunkVolume) {
let space = trunkVolume - newValue
print ("\(brand)\(model) объем багажника: \(space)")
} else { print("Неверный ввод в \(brand)\(model) багажник полон.")}
}
}
var engineState : engineState {
willSet {
if newValue == .включено {
print ("\(brand)\(model) зажигание включено")
} else {print("\(brand)\(model) зажигание выключено")}
}
}
var windowState : windowState {
willSet {
if newValue == .открыты {
print("\(brand)\(model) окна открыты")
} else { print("\(brand)\(model) окна закрыты") }
}
}
var trunkState : trunkState
mutating func emptyTrunck() {
self.trunkState = .пустой
print ("\(brand)\(model) багажник пуст")
}
}

struct someTruck {
let brand : String
let model : String
var color : String
mutating func changeColor(c:String) {
switch c {
case "черный":
self.color = "черный"
case "синий":
self.color = "синий"
case "зеленый":
self.color = "зеленый"
case "красный":
self.color = "красный"
default:
print("Такого цвета нет в наличии")
}
}
let release : Int
var bodyVolume : Double {
willSet {
if (trunkState == .пустой) && (bodyVolume > 0) && (bodyVolume != 0) && (newValue < bodyVolume) {
let space = bodyVolume - newValue
print ("\(brand)\(model) объем багажника: \(space)")
} else { print("Неверный ввод в \(brand)\(model) багажник полный")}
}
}
var engineState : engineState {
willSet {
    if newValue == .включено {
print ("\(brand)\(model) зажигание включено")
} else {print("\(brand)\(model) зажигание выключено")}
}
}
var windowState : windowState {
willSet {
if newValue == .открыты {
print("\(brand)\(model) открытые окна")
} else { print("\(brand)\(model) закрыте окна") }
}
}
var trunkState : trunkState
mutating func emptyTrunck() {
self.trunkState = .пустой
print ("\(brand)\(model) багажника нет")
}
}

var car1 = someCar(brand: "BMW ", model: "x7", color: "clear", release: 2021, trunkVolume: 480.0 , engineState: .выключено, windowState: .открыты, trunkState: .пустой)
var car2 = someCar(brand: "Лада ", model: "Приора", color: "clear", release: 2019, trunkVolume: 150, engineState: .выключено, windowState: .закрыты, trunkState: .полный)

var truckOne = someTruck(brand: "Tayota ", model: "Camry", color: "clear", release: 2020, bodyVolume: 100.0, engineState: .включено, windowState: .закрыты, trunkState: .пустой)
var truckTwo = someTruck(brand: "Audi ", model: "q7", color: "clear", release: 2017, bodyVolume: 150.0, engineState: .включено, windowState: .закрыты, trunkState: .пустой)

print("------------------------------------")
car1.engineState = .включено
car1.trunkVolume = 340.0
car1.changeColor(c:"белый")
car2.trunkVolume = 290.0
car2.trunkState = .пустой
car2.trunkVolume = 80.9
car2.windowState = .открыты
car2.changeColor(c: "желтый")
print("------------------------------------")
truckOne.engineState = .выключено
truckOne.windowState = .закрыты
truckTwo.engineState = .выключено
truckTwo.bodyVolume = 3000

print("------------------------------------")
print ("Информация первого автомобиля. Марка и модель: \(car1.brand)\(car1.model), год выпуска: \(car1.release), цвет: \(String(describing: car1.color)), объем багажника: \(car1.trunkVolume), зажигание \(car1.engineState)")
print("------------------------------------")
print ("Информация второго автомобиля. Марка и модель: \(car2.brand)\(car2.model), год выпуска: \(car2.release), цвет: \(String(describing: car2.color)), объем багажника: \(car2.trunkVolume), зажигание \(car2.engineState)")
print("------------------------------------")



