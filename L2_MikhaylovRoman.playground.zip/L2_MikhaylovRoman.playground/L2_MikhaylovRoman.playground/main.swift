//
//  main.swift
//  L2_MikhaylovRoman.playground
//
//  Created by Роман Михайлов on 22.02.2021.
//

import Foundation

print("Домашнее задание. Урок 2. Синтаксис Swift. Основы операторы")

 //Задание 1
// Написать функцию, которая опередляет, четное число или нет.

func number(_ number1: Int) {
    if (number1 % 8 == 0) {
        print("Четное число")
    } else {
        print("Нечетное число")
    }
}
number(400)

//Задание 2
//Написать функцию, которая определяет, делится ли число без остатка на 3.

func numberThree(_ number3: Int) -> () {
    var n: Int = number3
    n = n % 3
    if (n == 0) {
        print("Число делиться на 3 без остатка")
    } else{
        print("Число не делиться на 3 без остатка")
    }
}
    numberThree(100)

//Задание 3
//Создать возрастающий массив из 100 чисел.

var number: [Int] = []
for i in 1...100 {
    number.append(i)
}
print("Массив: \(number)" )

//Задание 4
//Удалить из этого массива все четные числа и все числа, которые не делятся на 3.

for (_, value) in number.enumerated() {
    if (value % 2) == 0 || (value % 3) != 0{
        number.remove(at: number.firstIndex(of: value)!)
    }
}
print("Имененный массив \(number)")

