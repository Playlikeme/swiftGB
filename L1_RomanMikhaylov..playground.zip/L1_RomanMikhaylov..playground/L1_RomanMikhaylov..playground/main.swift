//
//  main.swift
//  L1_RomanMikhaylov..playground
//
//  Created by Роман Михайлов on 15.02.2021.
//

import Foundation
//1 задание
print("Решение квадратного уровнения ax2 + bx + c = 0")
let a: Double =  750
let b: Double = 52
let c: Double = -68

let x1: Double
let x2: Double
let D:Double = b * b - 4 * a * c

if (D > 0) {
    x1 = -b + sqrt(D) / (2 * a)
    x2 = -b - sqrt(D) / (2 * a)
    print(" Уравнение имеет 2 корня : x1 = \(x1), x2 = \(x2) ")
} else if (D == 0) {
    x1 = -b / (2 * a)
    print("Уравнение имеет 1 корень: x1 = \(x1)")
} else {
    print("Нет корней")
}

//2 задание
print("Даны катеты треугольника. Найти площадь, периметр и гипотенузу")
let catet1 = 18
let catet2 = 32

var hypotenuse = sqrt(Double(catet1 + catet2*catet2))

hypotenuse = Double(round(hypotenuse*100)/100)

let perimetr = Double(catet1) + Double(catet2) + hypotenuse

let square = Double(catet1 * catet2) / 2

print("При заданных катетах \(catet1) и \(catet2) гипотенуза равна \(hypotenuse), периметр равен \(perimetr), площадь равна \(square)")
